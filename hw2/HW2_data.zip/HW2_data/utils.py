import random
from numpy.random import choice
import math
import sys
import pickle
import os

KMEANS = "kmeans"
KPP = "kpp"
TF_IDF = "tfidf"
TF = "tf"
DEV = "HW2_dev"
TEST = "HW2_test"

inverse_doc_frequency = {}
distances = {}
SET = ""
METRIC = ""

def init_variables(set_value,metric_value):
	global SET, METRIC, distances
	SET = set_value
	METRIC = metric_value
	with open(SET+".docVectors","r") as doc_vec:
		N = len(doc_vec.readlines())

	with open(SET+".df","r") as doc_frequency:
		for line in doc_frequency.readlines():
			df = line.strip("\n").split(":")
			inverse_doc_frequency[df[0]] = math.log(N/float(df[1]))

	if os.path.exists(SET+"_"+METRIC+"_distances.p"):
		distances = pickle.load(open(SET+"_"+METRIC+"_distances.p", "rb" ))

class Document:
	
	def __init__(self,doc_id,doc = None,metric = TF):
		self.doc_id = int(doc_id)
		self.terms = {}
		self.centroid = None
		self.metric = metric
		self.norm = 0.0
		if doc != None:
			self.initialize_doc(doc)
	def __str__(self):
		return str(self.terms)

	def similarity(self,centroid):
		similarity = 0.0
		for t in self.terms:
			# if t not in self.terms:
			# 	frequency = 0.0
			# else:
			# 	frequency = self.terms[t]
			#cosine similarity
			if t not in centroid.vector:
				continue
			similarity += centroid.vector[t] * self.terms[t]/(self.norm*(centroid.norm if centroid.norm > 0.0 else 1.0))
		

		return similarity

	def add_term(self,term,frequency):

		self.terms[int(term)] = float(frequency)
		if self.metric == TF_IDF:
			self.terms[term] *=inverse_doc_frequency[term]

	def update_cluster(self,centroid_list):
		max_sim = -1
		new_c = None
		for c in centroid_list:
			similarity = self.similarity(c)
			if similarity > max_sim:
				max_sim = similarity
				new_c = c

		if self.centroid == None or new_c.c_id != self.centroid.c_id:
			if self.centroid != None:
				self.centroid.docs.remove(self)
			new_c.docs.add(self)
			self.centroid = new_c
		return max_sim


	def initialize_doc(self,doc_string):
		doc_string = doc_string.strip("\n").split(" ")
		for d in doc_string:
			d = d.split(":")
			if len(d) > 1:
				self.add_term(d[0],int(d[1]))
				self.norm += int(d[1])**2
		self.norm= math.sqrt(self.norm)


class Centroid:

	def __init__(self,c_id,size,method = KMEANS,documents = [],centroid_list =[]):
		self.size = size
		self.norm = 0.0
		self.method = method
		self.doc_id = -1
		self.vector = self.initialize_centroid(documents,centroid_list)
		self.c_id = c_id
		self.docs = set()

	def initialize_centroid(self,documents =[] ,centroid_list = []):
		if self.method == KMEANS or len(documents) == 0:
			return self.initialize_kmeans()
		elif KPP:
			return self.initialize_kpp(documents,centroid_list)
		else:
			raise Exception("Wrong method!")

	def initialize_kmeans(self):
		c ={}
		for i in range(self.size):
			c[int(i)] = random.randint(0,5)
			self.norm += c[int(i)]**2
		self.norm = math.sqrt(self.norm)
		return c
	def distance_to_power_of_two_documents(self,doc_1,doc_2):
		dist = 0.0
		for t in doc_1.terms:
			
			d1_dist = doc_1.terms[int(t)]
			if not t in doc_2.terms:
				d2_dist = 0.0
			else:
				d2_dist = doc_2.terms[int(t)]
			dist += self.distance_to_power_of_two(d1_dist,d2_dist)
		for t in doc_2.terms:
			if t not in doc_1.terms:
				dist += self.distance_to_power_of_two(0.0,doc_2.terms[int(t)])
		return dist

	def distance_to_power_of_two(self,a,b):
		return (a-b)**2

	def initialize_kpp(self,documents,centroid_list):

		if not distances:
			print "Initializing distances"
			for i in range(len(documents)):
				if not i in distances:
					distances[i] = {}
				for j in range(i,len(documents)):
					if not j in distances:
						distances[j]= {}
					dist = self.distance_to_power_of_two_documents(documents[i],documents[j])
					distances[i][j] = dist
			pickle.dump( distances, open( SET+"_"+METRIC+"_distances.p", "wb" ) )
					


		if len(centroid_list) == 0:
			doc = documents[random.randint(0,len(documents))]
			self.doc_id = doc.doc_id
			return doc.terms.copy()

		v = {}
		doc_dist = [0.0]*len(documents)

		for i,d in enumerate(documents):
			for c in centroid_list:
				dist = distances[min(i,c.doc_id)][max(i,c.doc_id)]

				if doc_dist[i] < dist:
					doc_dist[i] = dist

		new_c = choice(len(documents),1,p=[i / sum(doc_dist) for i in doc_dist])
		self.doc_id = documents[new_c].doc_id
		return documents[new_c].terms.copy()



	def update_centroid(self):
		new_vec ={}
		self.norm = 0.0
		if len(self.docs) == 0:
			self.vector = self.initialize_centroid()

		for d in self.docs:
			for t in d.terms:
				if not t in new_vec:
					new_vec[t] =0.0
				new_vec[t] +=d.terms[t]/len(self.docs)
		self.vector = new_vec

		for i in range(self.size):
			if str(i) not in self.vector:
				self.vector[str(i)] = 0.0
			self.norm +=self.vector[str(i)]**2
		self.norm = math.sqrt(self.norm)


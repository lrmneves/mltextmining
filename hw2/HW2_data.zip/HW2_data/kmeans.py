import numpy as np
import scipy
import matplotlib.pyplot as plt
import sys
from utils import *
def reset_centroids(centroids):
	for c in centroids:
		for doc in list(c.docs):
			doc.centroid = None
			c.docs.remove(doc)
	return []
def update_centroid(c):
	c.update_centroid()
def run_kmeans(num_clusters,documents,size,method,residual_list = None,MAX_IT = 50,TRIES = 10):
	centroids = []
	start = 2
	if residual_list == None:
		start = num_clusters
		residual_list = [0.0]
	it_ave = [0.0] * len(residual_list)
	for k in range(start,num_clusters+1):
		print "# of clusters: " + str(k)
		for j in range(TRIES):
			centroids = reset_centroids(centroids)
			for i in range(k):
				c = Centroid(i,size,method = method,documents = documents,centroid_list =centroids)
				centroids.append(c)
			
			past_residual = 0.0

			count = 0
			for i in range(MAX_IT):
				residual = 0.0
				count +=1
				for d in documents:
					residual+= d.update_cluster(centroids)
				
				if abs(past_residual - residual) < 0.01:
					break
				else:
					past_residual = residual
							
				for c in centroids:
					c.update_centroid()

			it_ave[k-start] += count/TRIES
			residual_list[k-start]+=past_residual/TRIES
	
	for r in range(len(residual_list)):
		value = r+2
		if len(residual_list) == 1:
			value = num_clusters
		print "For %d clusters, average similarity was %f"%(value,residual_list[r])
		print "Average # of iterations: %d"%(it_ave[r])
	return centroids
def main():

	if len(sys.argv) != 4:
		print "Expect method ('kmeans' or 'kpp') set ('HW2_dev' or 'HW2_test') and metric ('tf' or 'tfidf')"
		print sys.argv
		sys.exit()

	METHOD = sys.argv[1].lower()
	SET = sys.argv[2]
	METRIC = sys.argv[3].lower()

	

	if METHOD != KMEANS and METHOD != KPP:
		print "Invalid method."
		sys.exit()
	if SET != DEV and SET != TEST:
		print "Invalid set."
		sys.exit()
	if METRIC != TF and METRIC != TF_IDF:
		print "Invalid metric."
		sys.exit()
	print METHOD
	documents = []
	

	with open(SET+".docVectors","r") as doc_vec:
		doc_id = 0
		for line in doc_vec.readlines():
			d = Document(doc_id,line)
			documents.append(d)
			doc_id+=1

	with open(SET+".dict") as term_dict:
		size = len(term_dict.readlines())

	init_variables(SET,METRIC)
	
	k = 100
	residual_list = [0]*(k-1)
	run_kmeans(k,documents,size,residual_list = residual_list,method = METHOD)

	plt.plot([i for i in range(2,k+1)], residual_list)
	plt.savefig(METHOD+"_"+SET+"_"+METRIC+'.png')

	centroids = run_kmeans(67,documents,size,method = METHOD)

	with open(METHOD +"_"+SET+"_"+METRIC+"_document_file.txt","w") as output:
		for c in centroids:
			for d in c.docs:
				output.write("%d %d\n"%(d.doc_id,c.c_id))


if __name__ == "__main__":
    main()


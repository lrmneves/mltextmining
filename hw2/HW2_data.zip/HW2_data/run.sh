python kmeans.py kmeans HW2_dev tf
python kmeans.py kmeans HW2_dev tfidf
python kmeans.py kpp HW2_dev tf
python kmeans.py kpp HW2_dev tfidf
python kmeans.py kmeans HW2_test tf
python kmeans.py kmeans HW2_test tfidf
python kmeans.py kpp HW2_test tf
python kmeans.py kpp HW2_test tfidf
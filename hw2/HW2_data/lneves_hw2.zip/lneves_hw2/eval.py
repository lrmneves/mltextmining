# script to evaluate the clusters
import sys

gold = open("HW2_dev.gold_standards", "r")
goldClusters = []
goldDict = dict()
eventCounter = 0
docCounter = 0
for line in gold:
	cluster = line.strip()

	if cluster != "unlabeled":
		if cluster not in goldDict:
			goldDict[cluster] = eventCounter
			eventCounter += 1

		clusterID = goldDict[cluster]
		while len(goldClusters) <= clusterID:
			goldClusters.append([])
		goldClusters[clusterID].append(docCounter)

	docCounter += 1
gold.close()

def getMacroF1(assignments):
	global goldClusters

	sysClusters = []
	

	for i in range(len(assignments)):
		cluster = assignments[i]
		while len(sysClusters) <= cluster:
			sysClusters.append([])
		sysClusters[cluster].append(i)

	# for each gold cluster, find the system cluster that maximizes F1
	clusterF1s = []
	for goldCluster in goldClusters:
		bestF1 = -1

		for sysCluster in sysClusters:
			tp = 0
			fp = 0
			fn = 0
			for item in goldCluster:
				if item in sysCluster:
					tp += 1.0
				else:
					fn += 1.0
			for item in sysCluster:
				if item not in goldCluster:
					fp += 1.0

			# if none match, just ignore	
			if tp == 0:
				continue

			precision = tp / (tp+fp)
			recall = tp / (tp+fn)
			f1 = 2*precision*recall/(precision+recall)

			if f1 > bestF1:
				bestF1 = f1
		
		clusterF1s.append(bestF1)

	macroF1 = 0
	for item in clusterF1s:
		macroF1 += item
	macroF1 = macroF1 / len(clusterF1s)
	return macroF1
	# print "Macro F1 = " + str(macroF1)





